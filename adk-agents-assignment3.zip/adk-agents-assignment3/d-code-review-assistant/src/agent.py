"""
Production-Quality Code Review Assistant — built with Google ADK.

Pipeline (SequentialAgent):
  1. StaticAnalysisAgent -> runs `ruff` (lint) over a diff/file set via a
     FunctionTool and reports findings as structured data
  2. ReviewerAgent       -> LLM review for design, correctness, security,
     and style, informed by the static-analysis findings
  3. ReportAgent         -> merges both into a single PR-ready review comment

Run locally:
    pip install ruff
    export GOOGLE_API_KEY=<your Gemini API key>
    adk run d-code-review-assistant/src

Reference:
  https://codelabs.developers.google.com/adk-code-reviewer-assistant/instructions?hl=en#0
  https://github.com/ayoisio/adk-code-review-assistant
"""

import json
import os
import subprocess

from google.adk.agents import LlmAgent, SequentialAgent
from google.adk.tools import FunctionTool

MODEL = "gemini-2.5-flash"


def run_static_analysis(target_path: str) -> dict:
    """Runs `ruff` static analysis over a file or directory and returns
    structured findings (rule violations with file/line/message).

    Args:
        target_path: Path to a file or directory to lint.

    Returns:
        dict with keys: success (bool), findings (list), error (str or None).
    """
    if not os.path.exists(target_path):
        return {"success": False, "findings": [], "error": f"path not found: {target_path}"}
    try:
        result = subprocess.run(
            ["ruff", "check", target_path, "--output-format=json"],
            capture_output=True,
            text=True,
            timeout=60,
        )
        # ruff exits non-zero when it finds violations; that's expected.
        findings = json.loads(result.stdout or "[]")
        simplified = [
            {
                "file": f.get("filename"),
                "line": f.get("location", {}).get("row"),
                "code": f.get("code"),
                "message": f.get("message"),
            }
            for f in findings
        ]
        return {"success": True, "findings": simplified, "error": None}
    except FileNotFoundError:
        return {
            "success": False,
            "findings": [],
            "error": "ruff not installed. Install with `pip install ruff`.",
        }
    except subprocess.TimeoutExpired:
        return {"success": False, "findings": [], "error": "ruff timed out after 60s"}
    except json.JSONDecodeError:
        return {"success": False, "findings": [], "error": "could not parse ruff output"}


static_analysis_tool = FunctionTool(func=run_static_analysis)

static_analysis_agent = LlmAgent(
    name="code_review_static_analyzer",
    model=MODEL,
    description="Runs automated lint/static analysis over the target code and summarizes it.",
    instruction="""You are a static-analysis runner. The user will give you a
file or directory path to review (in `target_path`). Call `run_static_analysis`
with that path, then summarize the findings grouped by severity/category
(style, correctness, complexity, imports, etc.) in a short structured
markdown list. If the tool errors (e.g. ruff not installed, path not found),
report that clearly and continue with an empty findings summary rather than
blocking the pipeline.""",
    tools=[static_analysis_tool],
    output_key="static_findings",
)

reviewer_agent = LlmAgent(
    name="code_review_reviewer",
    model=MODEL,
    description="Performs an LLM-driven design, correctness, and security review.",
    instruction="""You are a senior engineer doing a production code review.
You have these automated static-analysis findings already:

{static_findings}

Now do a deeper review covering what static analysis can't catch:
- Correctness: logic errors, edge cases, off-by-one, null/undefined handling
- Security: injection risks, secrets handling, unsafe deserialization, auth gaps
- Design: separation of concerns, naming, testability, error handling
- Performance: obvious inefficiencies (N+1 patterns, unnecessary work in loops)

For each issue found: cite the file/function, explain the risk, and give a
concrete suggested fix. Note validly good patterns too, briefly — a review
isn't only criticism. If you don't have the actual code content in context,
say explicitly that this review is based on the static findings only and
ask for the specific file contents to go deeper.""",
    output_key="review_notes",
)

report_agent = LlmAgent(
    name="code_review_reporter",
    model=MODEL,
    description="Merges static findings and review notes into one PR-ready comment.",
    instruction="""Combine the following into a single, well-formatted PR
review comment (markdown), ready to post on a pull request:

## Static Analysis
{static_findings}

## Senior Review Notes
{review_notes}

Structure the final output as:
1. **Summary** (2-3 sentences, overall verdict: approve / approve with
   comments / request changes)
2. **Must Fix** (blocking issues)
3. **Suggestions** (non-blocking improvements)
4. **Nice Work** (1-2 positive call-outs, if any)

Keep it crisp — this is what a human reviewer will actually read and post.""",
    output_key="final_review",
)

root_agent = SequentialAgent(
    name="code_review_assistant",
    description=(
        "Production-quality code review pipeline: static analysis + LLM "
        "design/security review, merged into a single PR-ready comment."
    ),
    sub_agents=[static_analysis_agent, reviewer_agent, report_agent],
)
