# d — Production-Quality Code Review Assistant

## What it does
A 3-stage `SequentialAgent` pipeline:
1. **Static Analyzer** — runs `ruff check --output-format=json` on a target
   path via a `FunctionTool`, summarizes findings
2. **Reviewer** — LLM review for correctness, security, design, performance,
   informed by the static findings
3. **Reporter** — merges both into one PR-ready review comment (Summary /
   Must Fix / Suggestions / Nice Work)

## Setup
```bash
cd d-code-review-assistant
pip install -r requirements.txt
export GOOGLE_API_KEY=<your Gemini API key>
```

## Run
```bash
adk run src
# example prompt:
# "Review the code at ../e-ecommerce-agent/src/agent.py"
```

## Execution walkthrough
`run_static_analysis` was tested directly against a real file in this repo
(`e-ecommerce-agent/src/agent.py`) — see `artifacts/local_tool_test_run.txt`.
Result: 0 lint violations, tool call succeeded end-to-end.

- [x] Static analysis tool verified against real code (0 findings)
- [x] Verified against deliberately flawed code (`artifacts/sample_bad_code/bad.py`)
      — correctly surfaced unsorted imports, 3 unused imports, 1 unused
      local variable
- [ ] Paste full pipeline run (reviewer + reporter stages) once a Gemini API
      key is available

## Status
Code complete, static-analysis tool independently verified working. The LLM
review and report stages need a Gemini API key, not available in this
environment, to produce the full walkthrough and video.
