import os
import sys
import json

def  add(a,b):
    x=1
    return a+b

class foo:
    def __init__(self):
        pass
