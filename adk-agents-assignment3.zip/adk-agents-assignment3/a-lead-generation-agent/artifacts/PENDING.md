Artifacts (screenshots, sample runs, logs) to be added here once run with a live Gemini API key.
