"""
Deep Research Agent for Lead Generation — built with Google ADK.

Pipeline (SequentialAgent):
  1. PlannerAgent   -> breaks the lead-gen brief into research sub-questions
  2. ResearcherAgent -> runs google_search per sub-question, collects findings
  3. SynthesizerAgent -> turns findings into a structured lead-gen report
     (ICP fit, company signals, contact points, outreach angle)

Run locally:
    export GOOGLE_API_KEY=<your Gemini API key>
    adk run a-lead-generation-agent/src
    # or
    adk web   # launches the ADK dev UI from the parent directory

Reference:
  https://cloud.google.com/blog/products/ai-machine-learning/build-a-deep-research-agent-with-google-adk
  https://github.com/MagnIeeT/leadGenerationAgentADK
"""

from google.adk.agents import LlmAgent, SequentialAgent
from google.adk.tools import google_search

MODEL = "gemini-2.5-flash"

planner_agent = LlmAgent(
    name="lead_research_planner",
    model=MODEL,
    description="Breaks a lead-generation brief into concrete research sub-questions.",
    instruction="""You are a B2B lead-generation research planner.
Given a target company / industry / persona brief, output 4-6 concrete,
search-ready sub-questions that would help qualify this lead, e.g.:
  - What does the company do and who are its main competitors?
  - What is their current tech stack / vendor relationships?
  - Recent funding, leadership changes, or expansion news?
  - Who is the likely economic buyer / decision maker for this product?
  - What pain points or initiatives suggest they need this solution now?
Output ONLY a numbered list of sub-questions, nothing else.""",
    output_key="research_plan",
)

researcher_agent = LlmAgent(
    name="lead_research_researcher",
    model=MODEL,
    description="Executes web research against the research plan using Google Search.",
    instruction="""You are a research analyst. You are given a numbered list of
research sub-questions in `research_plan`:

{research_plan}

For EACH sub-question, use the google_search tool to find current, credible
information. Summarize findings per sub-question in 2-4 sentences, citing the
source (title + URL). Be factual; do not speculate when search results are
thin — say so explicitly.

Output format:
### <sub-question>
<findings with inline source citations>
""",
    tools=[google_search],
    output_key="research_findings",
)

synthesizer_agent = LlmAgent(
    name="lead_research_synthesizer",
    model=MODEL,
    description="Synthesizes research findings into a structured lead-gen report.",
    instruction="""You are a sales development researcher writing a lead qualification
brief for an Account Executive. Using the findings below:

{research_findings}

Produce a structured markdown report with these sections:
1. **Company Snapshot** — what they do, size signals, industry
2. **ICP Fit Signals** — evidence they match an ideal-customer profile
3. **Buying Triggers** — funding, hiring, leadership, tech-stack signals
   that suggest timing
4. **Likely Decision Maker(s)** — role/title to target, with reasoning
5. **Suggested Outreach Angle** — one tailored opening line referencing a
   specific signal found above
6. **Confidence & Gaps** — what's well-supported vs. speculative

Keep it concise and actionable — this is read by a busy AE.""",
    output_key="lead_report",
)

root_agent = SequentialAgent(
    name="lead_generation_deep_research_agent",
    description=(
        "End-to-end deep research pipeline that turns a company/persona brief "
        "into a qualified, actionable lead-generation report."
    ),
    sub_agents=[planner_agent, researcher_agent, synthesizer_agent],
)
