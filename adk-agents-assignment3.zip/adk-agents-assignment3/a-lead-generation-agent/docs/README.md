# a — Deep Research Agent for Lead Generation

## What it does
A 3-stage `SequentialAgent` pipeline that turns a company/persona brief into
a structured, actionable lead-qualification report:

1. **Planner** — breaks the brief into 4-6 concrete research sub-questions
2. **Researcher** — runs `google_search` per sub-question, cites sources
3. **Synthesizer** — produces a markdown report: ICP fit, buying triggers,
   likely decision maker, outreach angle, confidence/gaps

## Setup
```bash
cd a-lead-generation-agent
pip install -r requirements.txt
cp .env.example .env   # fill in GOOGLE_API_KEY
```

## Run
```bash
adk run src
# interactive example prompt:
# "Research Acme Robotics (acme-robotics.com) as a lead for our DevOps
#  automation platform, targeting mid-market manufacturing."
```
Or launch the dev UI: `adk web` from this folder.

## Execution walkthrough (fill in once run with a real API key)
- [ ] Paste the planner's sub-question list here
- [ ] Paste a sample of the researcher's cited findings
- [ ] Paste the final synthesized lead report
- [ ] Note latency / token usage observations

## Status
Code complete and import-tested (`python3 -c "import src.agent"` succeeds).
Not yet run against a live Gemini API key in this environment — no
credentials available. Run locally with your own `GOOGLE_API_KEY` to
produce the walkthrough output above and for the video recording.
