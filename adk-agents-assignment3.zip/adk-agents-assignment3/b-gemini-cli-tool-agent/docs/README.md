# b — Advanced Tool Agent: Gemini CLI inside an ADK Pipeline

## What it does
A single `LlmAgent` orchestrator that treats the `gemini` CLI as a tool
(`run_gemini_cli`, a `FunctionTool` wrapping a `subprocess` call). The
orchestrator decides when a request needs filesystem-grounded reasoning
(repo summaries, diff explanations, commit messages) and delegates those to
the CLI, which has direct access to the local filesystem; it answers
everything else itself.

## Setup
```bash
cd b-gemini-cli-tool-agent
pip install -r requirements.txt
npm install -g @google/gemini-cli
gemini auth login          # or export GEMINI_API_KEY
export GOOGLE_API_KEY=<your Gemini API key>   # for the ADK orchestrator
```

## Run
```bash
adk run src
# example prompt:
# "Summarize what this repo does and draft a commit message for the
#  current uncommitted changes." (working_directory defaults to ".")
```

## Execution walkthrough (fill in once run with CLI + API key available)
- [ ] Paste a transcript where the orchestrator calls `run_gemini_cli`
- [ ] Paste the CLI's filesystem-grounded output
- [ ] Note one case where the orchestrator correctly answered directly
      without invoking the tool

## Status
Code complete and import-tested. The `run_gemini_cli` tool itself has
graceful error handling tested for the "CLI not installed" path (confirmed
in this sandbox, which has no `gemini` CLI or Node global install). Full
end-to-end run needs the Gemini CLI installed/authenticated plus a Gemini
API key, neither available in this build environment.
