"""
Advanced Tool Agent: Gemini CLI as a tool inside an ADK pipeline.

Idea: the ADK orchestrator agent handles planning/routing, and delegates
heavy local code-aware tasks (reading a repo, running a shell-grounded
analysis) to the `gemini` CLI, invoked as a plain ADK FunctionTool via
subprocess. This mirrors the "ADK + Gemini CLI + Cloud Run" pattern.

Prereqs:
  npm install -g @google/gemini-cli
  gemini auth login   # or set GEMINI_API_KEY
  export GOOGLE_API_KEY=<your Gemini API key>   # for the ADK orchestrator itself

Run locally:
    adk run b-gemini-cli-tool-agent/src

Reference:
  https://medium.com/@derrickchwong/combine-adk-gemini-cli-and-cloud-run-c5dea5118853
  https://github.com/derrickchwong/gemini-cli-on-adk
"""

import shlex
import subprocess

from google.adk.agents import LlmAgent
from google.adk.tools import FunctionTool

MODEL = "gemini-2.5-flash"
GEMINI_CLI_TIMEOUT_SECONDS = 120


def run_gemini_cli(prompt: str, working_directory: str = ".") -> dict:
    """Runs the Gemini CLI non-interactively against a local directory and
    returns its stdout. Use this for tasks that need the CLI's filesystem-aware
    context (reading/summarizing a codebase, explaining a diff, drafting a
    commit message) rather than plain text generation.

    Args:
        prompt: The instruction/question to hand to the Gemini CLI.
        working_directory: Directory the CLI should run in (gives it repo context).

    Returns:
        dict with keys: success (bool), output (str), error (str or None).
    """
    try:
        cmd = ["gemini", "-p", prompt]
        result = subprocess.run(
            cmd,
            cwd=working_directory,
            capture_output=True,
            text=True,
            timeout=GEMINI_CLI_TIMEOUT_SECONDS,
        )
        if result.returncode != 0:
            return {
                "success": False,
                "output": result.stdout.strip(),
                "error": result.stderr.strip() or f"gemini CLI exited {result.returncode}",
            }
        return {"success": True, "output": result.stdout.strip(), "error": None}
    except FileNotFoundError:
        return {
            "success": False,
            "output": "",
            "error": (
                "gemini CLI not found on PATH. Install with "
                "`npm install -g @google/gemini-cli` and authenticate."
            ),
        }
    except subprocess.TimeoutExpired:
        return {
            "success": False,
            "output": "",
            "error": f"gemini CLI timed out after {GEMINI_CLI_TIMEOUT_SECONDS}s",
        }


gemini_cli_tool = FunctionTool(func=run_gemini_cli)

root_agent = LlmAgent(
    name="gemini_cli_tool_agent",
    model=MODEL,
    description=(
        "An ADK orchestrator agent that uses the Gemini CLI as a tool for "
        "filesystem-aware code tasks (repo summaries, diff explanations, "
        "commit-message drafting), while handling planning and conversation "
        "itself."
    ),
    instruction="""You are an engineering assistant orchestrator.

For any request that requires reading or reasoning over actual files in a
local repository (summarizing a codebase, explaining what changed in a
directory, drafting a commit message from local changes, inspecting project
structure), call the `run_gemini_cli` tool with a precise prompt and the
correct `working_directory`. The Gemini CLI has direct filesystem access and
will ground its answer in the real files.

For general reasoning, planning, or questions that don't need live filesystem
access, answer directly yourself — don't invoke the tool unnecessarily.

Always report whether the CLI call succeeded; if it failed, surface the error
and suggest a fix (e.g. CLI not installed, not authenticated, wrong path).""",
    tools=[gemini_cli_tool],
)
