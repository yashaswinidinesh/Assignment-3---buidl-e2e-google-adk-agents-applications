# c — MCP Tools-based Agent for Bug Assistance

## What it does
An `LlmAgent` connected to an MCP filesystem server (`MCPToolset` ->
`@modelcontextprotocol/server-filesystem`) scoped to a target codebase, plus
two local `FunctionTool`s (`file_bug_ticket`, `list_bug_tickets`) acting as a
lightweight ticket store. Given a bug report, it searches the real codebase
via MCP, proposes a root cause and fix, and files a structured triage ticket.

## Setup
```bash
cd c-mcp-bug-assistant
pip install -r requirements.txt
export GOOGLE_API_KEY=<your Gemini API key>
export BUG_ASSISTANT_REPO_PATH=/path/to/the/codebase/to/debug
# requires node/npx on PATH (used to launch the MCP filesystem server)
```

## Run
```bash
adk run src
# example prompt:
# "Users report a 500 error when calling POST /orders with an empty cart.
#  Stack trace mentions orders/service.py line ~84."
```

## Execution walkthrough (fill in once run against a real repo + API key)
- [ ] Paste the agent's MCP filesystem tool calls (files listed/read)
- [ ] Paste its root-cause explanation with cited file/line context
- [ ] Paste the `file_bug_ticket` call result
- [ ] Paste a `list_bug_tickets` call showing the filed ticket

## Status
Code complete and import-tested. The ticket-store tools (`file_bug_ticket`,
`list_bug_tickets`) were tested directly and work correctly (see
`artifacts/local_tool_test_run.txt`). Node/npx are available in the build
environment, so the MCP filesystem server should spawn cleanly, but the full
agent run (MCP tool calls + LLM reasoning) needs a Gemini API key, which
isn't available here — run with your own key to produce the walkthrough
above and for the video.
