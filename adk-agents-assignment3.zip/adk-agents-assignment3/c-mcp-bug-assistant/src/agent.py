"""
MCP Tools-based Agent for Bug Assistance — built with Google ADK.

Uses MCPToolset to connect to a Model Context Protocol server that exposes
filesystem access to a target codebase, so the agent can search source files,
read stack traces, and correlate them with code before proposing a fix /
triage summary. Mirrors the "software-bug-assistant" ADK sample pattern.

Prereqs:
  node + npx available (for the filesystem MCP server)
  export GOOGLE_API_KEY=<your Gemini API key>
  export BUG_ASSISTANT_REPO_PATH=/path/to/the/codebase/to/debug

Run locally:
    adk run c-mcp-bug-assistant/src

Reference:
  https://cloud.google.com/blog/topics/developers-practitioners/tools-make-an-agent-from-zero-to-assistant-with-adk
  https://github.com/google/adk-samples/tree/main/python/agents/software-bug-assistant
"""

import os

from google.adk.agents import LlmAgent
from google.adk.tools import FunctionTool
from google.adk.tools.mcp_tool.mcp_toolset import MCPToolset
from google.adk.tools.mcp_tool.mcp_session_manager import StdioConnectionParams
from mcp import StdioServerParameters

MODEL = "gemini-2.5-flash"
REPO_PATH = os.environ.get("BUG_ASSISTANT_REPO_PATH", os.getcwd())

# MCP filesystem server gives the agent sandboxed, read-capable access to the
# target codebase so it can locate the files implicated in a bug report.
filesystem_mcp_toolset = MCPToolset(
    connection_params=StdioConnectionParams(
        server_params=StdioServerParameters(
            command="npx",
            args=["-y", "@modelcontextprotocol/server-filesystem", REPO_PATH],
        ),
    ),
)


# Lightweight in-memory "ticket store" tool — stands in for a real issue
# tracker (Jira/GitHub Issues) MCP connector so the agent has something to log
# triage results to end-to-end without external credentials.
_TICKETS: list[dict] = []


def file_bug_ticket(title: str, severity: str, summary: str, suspected_files: str) -> dict:
    """Files a triaged bug ticket into the local ticket store.

    Args:
        title: Short bug title.
        severity: One of "low", "medium", "high", "critical".
        summary: Root-cause summary and reasoning.
        suspected_files: Comma-separated list of files implicated.

    Returns:
        dict with the created ticket, including its assigned id.
    """
    ticket = {
        "id": len(_TICKETS) + 1,
        "title": title,
        "severity": severity,
        "summary": summary,
        "suspected_files": [f.strip() for f in suspected_files.split(",") if f.strip()],
    }
    _TICKETS.append(ticket)
    return ticket


def list_bug_tickets() -> list[dict]:
    """Returns all bug tickets filed so far in this session."""
    return _TICKETS


file_ticket_tool = FunctionTool(func=file_bug_ticket)
list_tickets_tool = FunctionTool(func=list_bug_tickets)

root_agent = LlmAgent(
    name="mcp_bug_assistant",
    model=MODEL,
    description=(
        "A bug-triage assistant that uses MCP filesystem tools to search a "
        "real codebase for the source of a reported bug, then files a "
        "structured triage ticket."
    ),
    instruction=f"""You are a software bug assistant working against the
codebase rooted at: {REPO_PATH}

When given a bug report (error message, stack trace, or symptom description):
1. Use the filesystem MCP tools to list/read relevant files and locate the
   code path implicated by the report (search by function/class/file names
   mentioned in the stack trace; if none are given, explore likely
   directories).
2. Explain your root-cause hypothesis, citing exact file paths and line
   context you read.
3. Propose a concrete fix (code sketch or specific change) — don't just
   describe the bug.
4. Call `file_bug_ticket` to log a structured triage record (title, severity,
   summary, suspected_files).
5. If asked, call `list_bug_tickets` to show everything triaged so far.

Be precise: never claim to have read a file you did not actually fetch via
the MCP tools. If the codebase doesn't contain anything relevant, say so
plainly instead of guessing.""",
    tools=[filesystem_mcp_toolset, file_ticket_tool, list_tickets_tool],
)
