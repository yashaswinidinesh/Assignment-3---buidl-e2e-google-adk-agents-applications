# e — Production-Quality E-Commerce Agent

## What it does
A conversational shopping `LlmAgent` with 5 tools: `search_products`,
`get_product_details`, `add_to_cart`, `view_cart`, `checkout`, backed by an
in-memory product catalog + cart. This stands in for the AlloyDB-backed
product DB in the reference codelab — swap the `_CATALOG`/`_CART` module
globals for an MCP/AlloyDB toolset for a real production deployment.

## Setup
```bash
cd e-ecommerce-agent
pip install -r requirements.txt
export GOOGLE_API_KEY=<your Gemini API key>
```

## Run
```bash
adk run src
# example conversation:
# "I need running shoes"
# "add 2 of the trail running shoes to my cart"
# "what's in my cart?"
# "checkout"
```

## Execution walkthrough
All 5 tool functions were tested directly end-to-end (search → add to cart
→ view cart → checkout) — see `artifacts/local_tool_test_run.txt`:
- `search_products("running")` → 3 matching products
- `add_to_cart("SKU-1001", 2)` → success, cart updated
- `add_to_cart("SKU-1004", 1)` → success, cart updated
- `view_cart()` → 2 line items, grand total $429.97
- `checkout()` → confirmed order with generated order ID, cart cleared

- [x] Tool logic verified end-to-end (no API key needed — pure Python)
- [ ] Paste full conversational agent run (LLM tool-calling) once a Gemini
      API key is available

## Status
Tool logic fully implemented and tested. The conversational LLM layer
(agent deciding which tool to call from natural language) needs a Gemini
API key, not available in this environment, to produce the full
walkthrough and video.
