"""
Production-Quality E-Commerce Agent — built with Google ADK.

Conversational shopping agent with tools for product search, product detail
lookup, cart management, and checkout. Ships with an in-memory product
catalog + cart so it runs end-to-end with zero external infra; swap
`_CATALOG`/session state for a real AlloyDB-backed MCP toolset (as in the
reference codelab) for production use.

Run locally:
    export GOOGLE_API_KEY=<your Gemini API key>
    adk run e-ecommerce-agent/src

Reference:
  https://codelabs.developers.google.com/codelabs/sports-agent-adk-mcp-alloydb?hl=en#8
  https://github.com/mtoscano84/sports-agent-adk-mcp-alloydb
"""

from google.adk.agents import LlmAgent
from google.adk.tools import FunctionTool

MODEL = "gemini-2.5-flash"

# --- In-memory product catalog (stand-in for an AlloyDB-backed product DB) ---
_CATALOG = [
    {"id": "SKU-1001", "name": "Trail Running Shoes", "category": "footwear",
     "price": 89.99, "stock": 42, "description": "Lightweight trail runners with grippy outsole."},
    {"id": "SKU-1002", "name": "Insulated Water Bottle 32oz", "category": "accessories",
     "price": 24.50, "stock": 150, "description": "Double-wall stainless steel, keeps cold 24h."},
    {"id": "SKU-1003", "name": "Performance Running Jacket", "category": "apparel",
     "price": 119.00, "stock": 18, "description": "Wind- and water-resistant, packable."},
    {"id": "SKU-1004", "name": "GPS Running Watch", "category": "electronics",
     "price": 249.99, "stock": 7, "description": "GPS, heart rate, 14-day battery."},
    {"id": "SKU-1005", "name": "Compression Socks (3-pack)", "category": "apparel",
     "price": 19.99, "stock": 200, "description": "Graduated compression for recovery."},
]

# Session-scoped cart (simple process-memory store; fine for a single-run demo).
_CART: dict[str, int] = {}


def search_products(query: str, category: str = "") -> list[dict]:
    """Searches the product catalog by free-text query and optional category.

    Args:
        query: Free-text search term (matched against name/description).
        category: Optional exact category filter (e.g. "footwear", "apparel").

    Returns:
        List of matching product dicts.
    """
    q = query.lower().strip()
    results = []
    for p in _CATALOG:
        if category and p["category"] != category.lower().strip():
            continue
        if not q or q in p["name"].lower() or q in p["description"].lower():
            results.append(p)
    return results


def get_product_details(product_id: str) -> dict:
    """Returns full details for a single product by its SKU id.

    Args:
        product_id: The product SKU, e.g. "SKU-1001".
    """
    for p in _CATALOG:
        if p["id"] == product_id:
            return p
    return {"error": f"no product found with id {product_id}"}


def add_to_cart(product_id: str, quantity: int = 1) -> dict:
    """Adds a product to the shopping cart, checking stock availability.

    Args:
        product_id: The product SKU to add.
        quantity: How many units to add (default 1).
    """
    product = next((p for p in _CATALOG if p["id"] == product_id), None)
    if not product:
        return {"success": False, "error": f"no product found with id {product_id}"}
    current = _CART.get(product_id, 0)
    if current + quantity > product["stock"]:
        return {
            "success": False,
            "error": f"only {product['stock']} in stock, cart would need {current + quantity}",
        }
    _CART[product_id] = current + quantity
    return {"success": True, "cart": view_cart()}


def view_cart() -> dict:
    """Returns the current cart contents with line totals and a grand total."""
    lines = []
    grand_total = 0.0
    for pid, qty in _CART.items():
        product = next((p for p in _CATALOG if p["id"] == pid), None)
        if not product:
            continue
        line_total = round(product["price"] * qty, 2)
        grand_total += line_total
        lines.append({
            "product_id": pid, "name": product["name"],
            "quantity": qty, "unit_price": product["price"], "line_total": line_total,
        })
    return {"lines": lines, "grand_total": round(grand_total, 2)}


def checkout() -> dict:
    """Finalizes the order from the current cart contents and clears the cart."""
    cart_snapshot = view_cart()
    if not cart_snapshot["lines"]:
        return {"success": False, "error": "cart is empty"}
    order = {
        "order_id": "ORD-" + str(abs(hash(str(cart_snapshot))))[:8],
        "lines": cart_snapshot["lines"],
        "total": cart_snapshot["grand_total"],
        "status": "confirmed",
    }
    _CART.clear()
    return {"success": True, "order": order}


root_agent = LlmAgent(
    name="ecommerce_shopping_agent",
    model=MODEL,
    description=(
        "A conversational shopping assistant that can search products, "
        "inspect details, manage a cart, and complete checkout."
    ),
    instruction="""You are a helpful e-commerce shopping assistant for an
outdoor/running gear store.

- Use `search_products` to find items matching what the shopper describes;
  ask a clarifying question only if the request is too vague to search.
- Use `get_product_details` when the shopper wants more info on one item.
- Use `add_to_cart` when they want to buy/add something; always confirm
  product name, quantity, and price back to them.
- Use `view_cart` to show current cart state when asked, or after changes.
- Use `checkout` only when the shopper explicitly confirms they want to
  complete the purchase; show the final order summary afterward.
- If stock is insufficient, explain how many are available and offer
  alternatives via search.
- Never invent products, prices, or stock levels — always get them from the
  tools.""",
    tools=[
        FunctionTool(func=search_products),
        FunctionTool(func=get_product_details),
        FunctionTool(func=add_to_cart),
        FunctionTool(func=view_cart),
        FunctionTool(func=checkout),
    ],
)
